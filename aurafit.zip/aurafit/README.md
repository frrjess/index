# AuraFit

A personal digital wardrobe assistant — upload your clothes, build outfits, and track when, where, and how good you felt wearing them.

This is the MVP: **Closet → Outfits → History**, plus a few smart touches (AI photo tagging, dominant-colour detection, a "what to wear" randomiser, repeat-wear warnings, and most/least-worn stats).

---

## Run it locally

You need [Node.js](https://nodejs.org) 18 or newer.

```bash
npm install
npm run dev
```

Then open the URL it prints (usually http://localhost:5173).

To make a production build:

```bash
npm run build      # outputs to /dist
npm run preview    # serve the built app locally
```

---

## What works out of the box

- **Upload clothes** — take or pick a photo. It's compressed on-device and the dominant colour is pulled straight from the image.
- **Organise** — seven categories: Tops, Bottoms, Jackets, Accessories, Shoes, Hats, Bags.
- **Build outfits** — combine pieces, name and tag the look, or hit *Surprise me*.
- **Track history** — log when/where you wore an outfit with a confidence rating; the timeline and repeat warnings keep you from wearing the same look too often.
- **Dark / light mode**, mobile-first layout, persistent across refreshes.

## Persistence

Data is stored in your browser via **IndexedDB** (`src/App.jsx` → the `store` object). It survives refreshes and holds photo data far better than `localStorage`. Clearing site data wipes it.

The `store` object is deliberately isolated with a tiny `get / set / del / list` API, so swapping it for **Supabase** (Postgres tables + a Storage bucket for images) is a contained change rather than a rewrite.

## AI tagging

The **Auto-tag with AI** button sends the photo to Claude and fills in type, name, colour, style, and season.

It works automatically inside the Claude artifact runtime. **Running locally it will fall back to manual tagging**, because a browser can't safely hold an API key. To enable it locally, stand up a small backend (or a Supabase Edge Function) that holds your `ANTHROPIC_API_KEY` and proxies the request, then point the `aiTag()` fetch in `src/App.jsx` at that endpoint.

Everything else runs fully offline.

---

## Project structure

```
aurafit/
├── index.html
├── package.json
├── vite.config.js
└── src/
    ├── main.jsx      # entry
    ├── index.css     # minimal global reset
    └── App.jsx       # the entire app (components + styles + storage)
```

## Roadmap (next up)

Weather-based suggestions · event-based looks · packing mode for trips · Supabase backend · shared/cloud wardrobe.
