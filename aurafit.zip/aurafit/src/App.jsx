import React, { useState, useEffect, useRef, useMemo, useCallback } from "react";
import {
  Plus, X, Sparkles, Sun, Moon, Heart, Calendar, MapPin, Trash2,
  Shuffle, Camera, Check, ChevronLeft, Shirt, Wand2, Clock, Layers,
  TrendingUp, Loader2, Tag, Star
} from "lucide-react";

/* ------------------------------------------------------------------ *
 *  AuraFit — a personal digital wardrobe assistant (MVP)
 *  Upload clothes · Build outfits · Track outfit history
 * ------------------------------------------------------------------ */

/* ---------- tiny utilities ---------- */
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
const today = () => new Date().toISOString().slice(0, 10);
const fmtDate = (iso) => {
  const d = new Date(iso + (iso.length === 10 ? "T00:00:00" : ""));
  return d.toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" });
};
const daysSince = (iso) => Math.floor((Date.now() - new Date(iso + "T00:00:00").getTime()) / 86400000);

const TYPES = [
  { id: "top", label: "Tops", emoji: "👕" },
  { id: "bottom", label: "Bottoms", emoji: "👖" },
  { id: "jacket", label: "Jackets", emoji: "🧥" },
  { id: "accessory", label: "Accessories", emoji: "🕶️" },
  { id: "shoes", label: "Shoes", emoji: "👟" },
  { id: "hat", label: "Hats", emoji: "🧢" },
  { id: "bag", label: "Bags", emoji: "👜" },
];
const typeMeta = (id) => TYPES.find((t) => t.id === id) || TYPES[0];

const SEASONS = ["spring", "summer", "autumn", "winter", "all"];
const TAG_PRESETS = ["casual", "party", "date night", "school", "holiday", "work", "festival", "dinner", "beach"];

/* ---------- colour naming ---------- */
const PALETTE = [
  ["black", "#111111"], ["white", "#ffffff"], ["grey", "#9095a0"], ["charcoal", "#3a3f4a"],
  ["navy", "#1e293b"], ["blue", "#3b82f6"], ["sky", "#7dd3fc"], ["denim", "#4a6a8a"],
  ["teal", "#14b8a6"], ["green", "#22c55e"], ["olive", "#6b7a3a"], ["yellow", "#eab308"],
  ["orange", "#fb923c"], ["red", "#ef4444"], ["pink", "#f472b6"], ["purple", "#a855f7"],
  ["brown", "#8b5a2b"], ["beige", "#d8c3a5"], ["cream", "#f2ead9"],
];
const hexToRgb = (h) => {
  const n = parseInt(h.replace("#", ""), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
};
const nearestColorName = (hex) => {
  const [r, g, b] = hexToRgb(hex);
  let best = "neutral", bd = Infinity;
  for (const [name, ph] of PALETTE) {
    const [pr, pg, pb] = hexToRgb(ph);
    const d = (r - pr) ** 2 + (g - pg) ** 2 + (b - pb) ** 2;
    if (d < bd) { bd = d; best = name; }
  }
  return best;
};

/* ---------- image processing (compress + dominant colour) ---------- */
function processImage(file, maxDim = 900, quality = 0.72) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      let { width, height } = img;
      if (width > height && width > maxDim) { height *= maxDim / width; width = maxDim; }
      else if (height > maxDim) { width *= maxDim / height; height = maxDim; }
      const canvas = document.createElement("canvas");
      canvas.width = width; canvas.height = height;
      const ctx = canvas.getContext("2d");
      ctx.drawImage(img, 0, 0, width, height);
      // dominant colour via coarse buckets
      let hex = "#9095a0";
      try {
        const { data } = ctx.getImageData(0, 0, width, height);
        const buckets = {};
        for (let i = 0; i < data.length; i += 4 * 17) {
          const a = data[i + 3];
          if (a < 128) continue;
          const r = data[i], g = data[i + 1], b = data[i + 2];
          // skip near-white background pixels so the garment wins
          if (r > 238 && g > 238 && b > 238) continue;
          const key = `${r >> 4},${g >> 4},${b >> 4}`;
          if (!buckets[key]) buckets[key] = { c: 0, r: 0, g: 0, b: 0 };
          const bk = buckets[key]; bk.c++; bk.r += r; bk.g += g; bk.b += b;
        }
        let top = null;
        for (const k in buckets) if (!top || buckets[k].c > top.c) top = buckets[k];
        if (top) {
          const to2 = (v) => Math.round(v / top.c).toString(16).padStart(2, "0");
          hex = `#${to2(top.r)}${to2(top.g)}${to2(top.b)}`;
        }
      } catch (e) { /* tainted canvas — keep default */ }
      const dataUrl = canvas.toDataURL("image/jpeg", quality);
      URL.revokeObjectURL(url);
      resolve({ dataUrl, colorHex: hex, colorName: nearestColorName(hex) });
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error("Could not read image")); };
    img.src = url;
  });
}

/* ---------- AI tagging (Claude vision) ---------- */
async function aiTag(dataUrl) {
  const base64 = dataUrl.split(",")[1];
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-6",
      max_tokens: 1000,
      messages: [{
        role: "user",
        content: [
          { type: "image", source: { type: "base64", media_type: "image/jpeg", data: base64 } },
          {
            type: "text",
            text:
              "You are a fashion cataloguer. Identify this single clothing item. " +
              "Respond with ONLY a JSON object, no prose, no markdown fences:\n" +
              '{"type": one of ["top","bottom","jacket","accessory","shoes","hat","bag"], ' +
              '"name": short 1-3 word name, ' +
              '"colorName": dominant colour word, ' +
              '"style": one word style e.g. casual/formal/sporty/streetwear/boho, ' +
              '"season": one of ["spring","summer","autumn","winter","all"]}',
          },
        ],
      }],
    }),
  });
  if (!res.ok) throw new Error("tag request failed");
  const data = await res.json();
  const text = (data.content || []).filter((b) => b.type === "text").map((b) => b.text).join("\n");
  const clean = text.replace(/```json/gi, "").replace(/```/g, "").trim();
  const parsed = JSON.parse(clean);
  return parsed;
}

/* ---------- persistence -------------------------------------------- *
 *  Same API works in two environments:
 *   • Claude artifact runtime  -> window.storage
 *   • Local / production build -> IndexedDB (persists across refreshes,
 *     and holds photo-sized data far better than localStorage)
 *  To move to the cloud, replace the idb* calls below with Supabase.
 * ------------------------------------------------------------------ */
const IDB_NAME = "aurafit";
const IDB_STORE = "kv";
function idbOpen() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(IDB_NAME, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(IDB_STORE);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
function idbReq(mode, fn) {
  return idbOpen().then((db) => new Promise((resolve, reject) => {
    const tx = db.transaction(IDB_STORE, mode);
    const r = fn(tx.objectStore(IDB_STORE));
    tx.oncomplete = () => resolve(r && r.result);
    tx.onerror = () => reject(tx.error);
  }));
}
const idbGet = (k) => idbReq("readonly", (os) => os.get(k)).then((v) => (v === undefined ? null : v));
const idbSet = (k, v) => idbReq("readwrite", (os) => os.put(v, k));
const idbDel = (k) => idbReq("readwrite", (os) => os.delete(k));
const idbKeys = (prefix) => idbReq("readonly", (os) => os.getAllKeys())
  .then((keys) => (keys || []).filter((k) => String(k).startsWith(prefix)));

const hasArtifactStorage = typeof window !== "undefined" && !!window.storage;
const store = {
  ok: true,
  async get(key) {
    try {
      if (hasArtifactStorage) { const r = await window.storage.get(key); return r ? r.value : null; }
      return await idbGet(key);
    } catch { return null; }
  },
  async set(key, value) {
    try { if (hasArtifactStorage) await window.storage.set(key, value); else await idbSet(key, value); } catch {}
  },
  async del(key) {
    try { if (hasArtifactStorage) await window.storage.delete(key); else await idbDel(key); } catch {}
  },
  async list(prefix) {
    try {
      if (hasArtifactStorage) { const r = await window.storage.list(prefix); return (r && r.keys) || []; }
      return await idbKeys(prefix);
    } catch { return []; }
  },
};

/* ================================================================== */
/*  APP                                                               */
/* ================================================================== */
export default function AuraFit() {
  const [theme, setTheme] = useState("dark");
  const [tab, setTab] = useState("closet");
  const [loading, setLoading] = useState(true);

  const [items, setItems] = useState([]);
  const [outfits, setOutfits] = useState([]);
  const [logs, setLogs] = useState([]);

  const [addOpen, setAddOpen] = useState(false);
  const [detailItem, setDetailItem] = useState(null);
  const [buildFor, setBuildFor] = useState(null);   // {} for new, {surprise:true}, or existing outfit
  const [detailOutfit, setDetailOutfit] = useState(null);
  const [wearFor, setWearFor] = useState(null);
  const [toast, setToast] = useState(null);

  const loaded = useRef(false);
  const flash = useCallback((msg) => { setToast(msg); setTimeout(() => setToast(null), 2200); }, []);

  /* ---- load once ---- */
  useEffect(() => {
    (async () => {
      const settings = await store.get("settings");
      if (settings && settings.theme) setTheme(settings.theme);
      const keys = await store.list("item:");
      const loadedItems = [];
      for (const k of keys) { const it = await store.get(k); if (it) loadedItems.push(it); }
      loadedItems.sort((a, b) => b.createdAt - a.createdAt);
      setItems(loadedItems);
      setOutfits((await store.get("outfits")) || []);
      setLogs((await store.get("logs")) || []);
      loaded.current = true;
      setLoading(false);
    })();
  }, []);

  /* ---- persist collections ---- */
  useEffect(() => { if (loaded.current) store.set("outfits", outfits); }, [outfits]);
  useEffect(() => { if (loaded.current) store.set("logs", logs); }, [logs]);
  useEffect(() => { if (loaded.current) store.set("settings", { theme }); }, [theme]);

  /* ---- item ops (per-key storage keeps each image under the 5MB cap) ---- */
  const addItem = async (item) => {
    const full = { ...item, id: uid(), createdAt: Date.now() };
    setItems((p) => [full, ...p]);
    await store.set("item:" + full.id, full);
    flash("Added to your closet");
  };
  const removeItem = async (id) => {
    setItems((p) => p.filter((i) => i.id !== id));
    setOutfits((p) => p.map((o) => ({ ...o, itemIds: o.itemIds.filter((x) => x !== id) })));
    await store.del("item:" + id);
    setDetailItem(null);
    flash("Removed");
  };

  /* ---- outfit ops ---- */
  const saveOutfit = (outfit) => {
    if (outfit.id) {
      setOutfits((p) => p.map((o) => (o.id === outfit.id ? outfit : o)));
      flash("Outfit updated");
    } else {
      setOutfits((p) => [{ ...outfit, id: uid(), createdAt: Date.now() }, ...p]);
      flash("Outfit saved");
    }
    setBuildFor(null);
  };
  const removeOutfit = (id) => {
    setOutfits((p) => p.filter((o) => o.id !== id));
    setLogs((p) => p.filter((l) => l.outfitId !== id));
    setDetailOutfit(null);
    flash("Outfit deleted");
  };
  const logWear = (log) => {
    setLogs((p) => [{ ...log, id: uid(), createdAt: Date.now() }, ...p]);
    setWearFor(null);
    flash("Logged — looking good ✨");
  };

  /* ---- derived stats ---- */
  const outfitStats = useMemo(() => {
    const m = {};
    for (const o of outfits) m[o.id] = { count: 0, last: null, conf: [] };
    for (const l of logs) {
      const s = m[l.outfitId]; if (!s) continue;
      s.count++; s.conf.push(l.confidence || 0);
      if (!s.last || l.date > s.last) s.last = l.date;
    }
    return m;
  }, [outfits, logs]);

  const itemWear = useMemo(() => {
    const m = {}; for (const it of items) m[it.id] = 0;
    for (const l of logs) {
      const o = outfits.find((x) => x.id === l.outfitId);
      if (o) for (const id of o.itemIds) if (m[id] != null) m[id]++;
    }
    return m;
  }, [items, outfits, logs]);

  const itemById = useCallback((id) => items.find((i) => i.id === id), [items]);

  if (loading) {
    return (
      <div className="af" data-theme={theme}>
        <Style />
        <div className="af-splash">
          <div className="af-logo-mark" />
          <p className="af-splash-txt">Opening your closet…</p>
        </div>
      </div>
    );
  }

  return (
    <div className="af" data-theme={theme}>
      <Style />

      {/* header */}
      <header className="af-header">
        <div className="af-brand">
          <span className="af-mark" />
          <span className="af-word">AuraFit</span>
        </div>
        <button className="af-icon-btn" onClick={() => setTheme((t) => (t === "dark" ? "light" : "dark"))}
          aria-label="Toggle theme">
          {theme === "dark" ? <Sun size={18} /> : <Moon size={18} />}
        </button>
      </header>

      {/* views */}
      <main className="af-main">
        {tab === "closet" && (
          <Closet items={items} itemWear={itemWear} onOpen={setDetailItem} onAdd={() => setAddOpen(true)} />
        )}
        {tab === "outfits" && (
          <Outfits outfits={outfits} stats={outfitStats} itemById={itemById}
            onOpen={setDetailOutfit}
            onBuild={() => setBuildFor({})}
            onSurprise={() => setBuildFor({ surprise: true })} />
        )}
        {tab === "history" && (
          <History logs={logs} outfits={outfits} items={items} itemWear={itemWear} itemById={itemById} />
        )}
      </main>

      {/* floating action */}
      {tab !== "history" && (
        <button className="af-fab" onClick={() => (tab === "closet" ? setAddOpen(true) : setBuildFor({}))}>
          <Plus size={22} strokeWidth={2.4} />
          <span>{tab === "closet" ? "Add piece" : "New outfit"}</span>
        </button>
      )}

      {/* bottom nav */}
      <nav className="af-nav">
        <NavBtn active={tab === "closet"} icon={<Shirt size={20} />} label="Closet" onClick={() => setTab("closet")} />
        <NavBtn active={tab === "outfits"} icon={<Layers size={20} />} label="Outfits" onClick={() => setTab("outfits")} />
        <NavBtn active={tab === "history"} icon={<Clock size={20} />} label="History" onClick={() => setTab("history")} />
      </nav>

      {/* modals */}
      {addOpen && <AddItem onClose={() => setAddOpen(false)} onSave={addItem} flash={flash} />}
      {detailItem && (
        <ItemDetail item={detailItem} worn={itemWear[detailItem.id] || 0}
          onClose={() => setDetailItem(null)} onDelete={() => removeItem(detailItem.id)} />
      )}
      {buildFor && (
        <BuildOutfit items={items} initial={buildFor} onClose={() => setBuildFor(null)} onSave={saveOutfit} flash={flash} />
      )}
      {detailOutfit && (
        <OutfitDetail outfit={detailOutfit} itemById={itemById}
          stat={outfitStats[detailOutfit.id]} logs={logs.filter((l) => l.outfitId === detailOutfit.id)}
          onClose={() => setDetailOutfit(null)}
          onWear={() => setWearFor(detailOutfit)}
          onEdit={() => { setBuildFor(detailOutfit); setDetailOutfit(null); }}
          onDelete={() => removeOutfit(detailOutfit.id)} />
      )}
      {wearFor && <WearLog outfit={wearFor} onClose={() => setWearFor(null)} onSave={logWear} />}

      {toast && <div className="af-toast">{toast}</div>}
    </div>
  );
}

/* ================================================================== */
/*  NAV                                                               */
/* ================================================================== */
function NavBtn({ active, icon, label, onClick }) {
  return (
    <button className={"af-navbtn" + (active ? " on" : "")} onClick={onClick}>
      {icon}<span>{label}</span>
    </button>
  );
}

/* ================================================================== */
/*  CLOSET                                                            */
/* ================================================================== */
function Closet({ items, itemWear, onOpen, onAdd }) {
  const [filter, setFilter] = useState("all");
  const shown = filter === "all" ? items : items.filter((i) => i.type === filter);

  return (
    <div className="af-view">
      <div className="af-viewhead">
        <div>
          <h1 className="af-h1">Closet</h1>
          <p className="af-sub">{items.length} {items.length === 1 ? "piece" : "pieces"}</p>
        </div>
      </div>

      {items.length > 0 && (
        <div className="af-filters">
          <Chip on={filter === "all"} onClick={() => setFilter("all")}>All</Chip>
          {TYPES.map((t) => (
            <Chip key={t.id} on={filter === t.id} onClick={() => setFilter(t.id)}>
              <span className="af-emoji">{t.emoji}</span>{t.label}
            </Chip>
          ))}
        </div>
      )}

      {items.length === 0 ? (
        <Empty
          icon="👗"
          title="Your closet is empty"
          body="Add your first piece — snap or upload a photo and AuraFit will tag it for you."
          cta="Add a piece" onCta={onAdd} />
      ) : shown.length === 0 ? (
        <p className="af-none">Nothing in this category yet.</p>
      ) : (
        <div className="af-masonry">
          {shown.map((it, i) => (
            <button key={it.id} className="af-card af-in" style={{ animationDelay: `${Math.min(i, 12) * 35}ms` }}
              onClick={() => onOpen(it)}>
              <div className="af-glow" style={{ background: it.colorHex }} />
              <img src={it.image} alt={it.name} loading="lazy" />
              <div className="af-cardmeta">
                <span className="af-cardname">{it.name || typeMeta(it.type).label}</span>
                {(itemWear[it.id] || 0) > 0 && <span className="af-wornpill">×{itemWear[it.id]}</span>}
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

/* ================================================================== */
/*  OUTFITS                                                           */
/* ================================================================== */
function Outfits({ outfits, stats, itemById, onOpen, onBuild, onSurprise }) {
  return (
    <div className="af-view">
      <div className="af-viewhead">
        <div>
          <h1 className="af-h1">Outfits</h1>
          <p className="af-sub">{outfits.length} saved {outfits.length === 1 ? "look" : "looks"}</p>
        </div>
        <button className="af-ghost" onClick={onSurprise}><Wand2 size={16} />What to wear</button>
      </div>

      {outfits.length === 0 ? (
        <Empty
          icon="✨"
          title="No outfits yet"
          body="Combine pieces from your closet into a look you can save, wear and track."
          cta="Build an outfit" onCta={onBuild} />
      ) : (
        <div className="af-outfitgrid">
          {outfits.map((o, i) => {
            const s = stats[o.id] || { count: 0, last: null };
            const recent = s.last && daysSince(s.last) <= 6;
            const imgs = o.itemIds.map(itemById).filter(Boolean).slice(0, 4);
            return (
              <button key={o.id} className="af-outfit af-in" style={{ animationDelay: `${Math.min(i, 12) * 40}ms` }}
                onClick={() => onOpen(o)}>
                <div className={"af-collage n" + imgs.length}>
                  {imgs.map((it) => (
                    <span key={it.id} className="af-tile">
                      <span className="af-glow soft" style={{ background: it.colorHex }} />
                      <img src={it.image} alt="" loading="lazy" />
                    </span>
                  ))}
                </div>
                <div className="af-outfitfoot">
                  <span className="af-outfitname">{o.name || "Untitled look"}</span>
                  <div className="af-outfitmeta">
                    {recent && <span className="af-recent">worn {daysSince(s.last)}d ago</span>}
                    {!recent && s.count > 0 && <span className="af-muted-sm">worn ×{s.count}</span>}
                    {s.count === 0 && <span className="af-muted-sm">never worn</span>}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ================================================================== */
/*  HISTORY                                                           */
/* ================================================================== */
function History({ logs, outfits, items, itemWear, itemById }) {
  const sorted = useMemo(() => [...logs].sort((a, b) => (a.date < b.date ? 1 : -1)), [logs]);
  const most = useMemo(() => {
    let id = null, n = -1;
    for (const k in itemWear) if (itemWear[k] > n) { n = itemWear[k]; id = k; }
    return n > 0 ? { it: itemById(id), n } : null;
  }, [itemWear, itemById]);
  const least = useMemo(() => {
    if (items.length === 0) return null;
    let id = null, n = Infinity;
    for (const it of items) { const w = itemWear[it.id] || 0; if (w < n) { n = w; id = it.id; } }
    return { it: itemById(id), n };
  }, [items, itemWear, itemById]);

  return (
    <div className="af-view">
      <div className="af-viewhead">
        <div>
          <h1 className="af-h1">History</h1>
          <p className="af-sub">{logs.length} {logs.length === 1 ? "wear" : "wears"} logged</p>
        </div>
      </div>

      {logs.length === 0 ? (
        <Empty
          icon="🗓️"
          title="No wear history yet"
          body="Open an outfit and tap “Wear today” to start tracking when and where you wore it."
        />
      ) : (
        <>
          <div className="af-stats">
            {most && (
              <div className="af-stat">
                <div className="af-stat-ic"><TrendingUp size={15} /></div>
                <div>
                  <span className="af-stat-lbl">Most worn piece</span>
                  <span className="af-stat-val">{most.it?.name || typeMeta(most.it?.type).label} · ×{most.n}</span>
                </div>
              </div>
            )}
            {least && least.n === 0 && (
              <div className="af-stat">
                <div className="af-stat-ic"><Sparkles size={15} /></div>
                <div>
                  <span className="af-stat-lbl">Give this some love</span>
                  <span className="af-stat-val">{least.it?.name || typeMeta(least.it?.type).label} · never worn</span>
                </div>
              </div>
            )}
          </div>

          <div className="af-timeline">
            {sorted.map((l) => {
              const o = outfits.find((x) => x.id === l.outfitId);
              const imgs = o ? o.itemIds.map(itemById).filter(Boolean).slice(0, 3) : [];
              return (
                <div key={l.id} className="af-tlrow af-in">
                  <div className="af-tldate">
                    <span className="af-tld">{fmtDate(l.date).split(" ")[0]}</span>
                    <span className="af-tlm">{fmtDate(l.date).split(" ")[1]}</span>
                  </div>
                  <div className="af-tlcard">
                    <div className="af-tlimgs">
                      {imgs.map((it) => <img key={it.id} src={it.image} alt="" />)}
                    </div>
                    <div className="af-tlinfo">
                      <span className="af-tlname">{o ? (o.name || "Untitled look") : "Deleted outfit"}</span>
                      <div className="af-tltags">
                        {l.occasion && <span className="af-inlinetag"><Tag size={11} />{l.occasion}</span>}
                        {l.location && <span className="af-inlinetag"><MapPin size={11} />{l.location}</span>}
                      </div>
                    </div>
                    <Hearts value={l.confidence} small readOnly />
                  </div>
                </div>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
}

/* ================================================================== */
/*  ADD ITEM (upload + AI tag)                                        */
/* ================================================================== */
function AddItem({ onClose, onSave, flash }) {
  const [img, setImg] = useState(null);
  const [colorHex, setColorHex] = useState("#9095a0");
  const [form, setForm] = useState({ type: "top", name: "", colorName: "", style: "", season: "all" });
  const [busy, setBusy] = useState(false);
  const [tagging, setTagging] = useState(false);
  const fileRef = useRef(null);

  const pick = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setBusy(true);
    try {
      const { dataUrl, colorHex, colorName } = await processImage(file);
      setImg(dataUrl);
      setColorHex(colorHex);
      setForm((f) => ({ ...f, colorName: f.colorName || colorName }));
    } catch { flash("Couldn't read that image"); }
    setBusy(false);
  };

  const runAi = async () => {
    if (!img) return;
    setTagging(true);
    try {
      const t = await aiTag(img);
      setForm((f) => ({
        type: TYPES.some((x) => x.id === t.type) ? t.type : f.type,
        name: t.name || f.name,
        colorName: t.colorName || f.colorName,
        style: t.style || f.style,
        season: SEASONS.includes(t.season) ? t.season : f.season,
      }));
      flash("Tagged with AI ✨");
    } catch { flash("AI tagging unavailable — tag it manually"); }
    setTagging(false);
  };

  const save = () => {
    if (!img) { flash("Add a photo first"); return; }
    onSave({ image: img, colorHex, ...form });
    onClose();
  };

  return (
    <Sheet title="Add a piece" onClose={onClose}>
      <input ref={fileRef} type="file" accept="image/*" capture="environment" hidden onChange={pick} />

      {!img ? (
        <button className="af-drop" onClick={() => fileRef.current?.click()} disabled={busy}>
          {busy ? <Loader2 className="af-spin" size={26} /> : <Camera size={26} />}
          <span className="af-drop-t">{busy ? "Processing…" : "Take or upload a photo"}</span>
          <span className="af-drop-s">Shoot against a plain background for the cleanest tag</span>
        </button>
      ) : (
        <>
          <div className="af-preview">
            <div className="af-glow big" style={{ background: colorHex }} />
            <img src={img} alt="preview" />
            <button className="af-repick" onClick={() => fileRef.current?.click()}>Change</button>
          </div>

          <button className="af-ai" onClick={runAi} disabled={tagging}>
            {tagging ? <Loader2 className="af-spin" size={17} /> : <Sparkles size={17} />}
            {tagging ? "Reading the fabric…" : "Auto-tag with AI"}
          </button>

          <Field label="Type">
            <div className="af-chiprow">
              {TYPES.map((t) => (
                <Chip key={t.id} on={form.type === t.id} onClick={() => setForm({ ...form, type: t.id })}>
                  <span className="af-emoji">{t.emoji}</span>{t.label}
                </Chip>
              ))}
            </div>
          </Field>

          <Field label="Name">
            <input className="af-input" placeholder="e.g. Cream knit jumper"
              value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          </Field>

          <div className="af-two">
            <Field label="Colour">
              <div className="af-inputwrap">
                <span className="af-swatch" style={{ background: colorHex }} />
                <input className="af-input" placeholder="colour" value={form.colorName}
                  onChange={(e) => setForm({ ...form, colorName: e.target.value })} />
              </div>
            </Field>
            <Field label="Style">
              <input className="af-input" placeholder="e.g. casual" value={form.style}
                onChange={(e) => setForm({ ...form, style: e.target.value })} />
            </Field>
          </div>

          <Field label="Season">
            <div className="af-chiprow">
              {SEASONS.map((s) => (
                <Chip key={s} on={form.season === s} onClick={() => setForm({ ...form, season: s })}>{s}</Chip>
              ))}
            </div>
          </Field>

          <button className="af-primary" onClick={save}><Check size={18} />Add to closet</button>
        </>
      )}
    </Sheet>
  );
}

/* ================================================================== */
/*  ITEM DETAIL                                                       */
/* ================================================================== */
function ItemDetail({ item, worn, onClose, onDelete }) {
  return (
    <Sheet title={item.name || typeMeta(item.type).label} onClose={onClose}>
      <div className="af-preview">
        <div className="af-glow big" style={{ background: item.colorHex }} />
        <img src={item.image} alt={item.name} />
      </div>
      <div className="af-detailtags">
        <span className="af-dt"><span className="af-emoji">{typeMeta(item.type).emoji}</span>{typeMeta(item.type).label}</span>
        {item.colorName && <span className="af-dt"><span className="af-swatch sm" style={{ background: item.colorHex }} />{item.colorName}</span>}
        {item.style && <span className="af-dt">{item.style}</span>}
        {item.season && <span className="af-dt">{item.season}</span>}
      </div>
      <div className="af-wornline">
        <Heart size={15} />{worn > 0 ? `Worn in ${worn} logged ${worn === 1 ? "wear" : "wears"}` : "Not worn yet"}
      </div>
      <button className="af-danger" onClick={onDelete}><Trash2 size={17} />Remove piece</button>
    </Sheet>
  );
}

/* ================================================================== */
/*  BUILD OUTFIT                                                      */
/* ================================================================== */
function BuildOutfit({ items, initial, onClose, onSave, flash }) {
  const editing = !!initial.id;
  const [name, setName] = useState(initial.name || "");
  const [selected, setSelected] = useState(initial.itemIds || []);
  const [tags, setTags] = useState(initial.tags || []);
  const [custom, setCustom] = useState("");

  const surprise = useCallback(() => {
    const pickOf = (t) => {
      const pool = items.filter((i) => i.type === t);
      return pool.length ? pool[Math.floor(Math.random() * pool.length)].id : null;
    };
    const core = ["top", "bottom", "shoes"].map(pickOf).filter(Boolean);
    const extras = ["jacket", "accessory", "hat", "bag"]
      .filter(() => Math.random() > 0.5).map(pickOf).filter(Boolean);
    const chosen = [...core, ...extras];
    setSelected(chosen);
    if (!name) setName("Surprise look");
    if (chosen.length === 0) flash("Add a few pieces first");
  }, [items, name, flash]);

  useEffect(() => { if (initial.surprise) surprise(); }, []); // eslint-disable-line

  const toggle = (id) => setSelected((p) => (p.includes(id) ? p.filter((x) => x !== id) : [...p, id]));
  const toggleTag = (t) => setTags((p) => (p.includes(t) ? p.filter((x) => x !== t) : [...p, t]));
  const addCustom = () => {
    const v = custom.trim().toLowerCase();
    if (v && !tags.includes(v)) setTags([...tags, v]);
    setCustom("");
  };

  const grouped = TYPES.map((t) => ({ t, list: items.filter((i) => i.type === t.id) })).filter((g) => g.list.length);

  const save = () => {
    if (selected.length === 0) { flash("Pick at least one piece"); return; }
    onSave({ id: initial.id, name: name.trim(), itemIds: selected, tags,
      createdAt: initial.createdAt });
  };

  return (
    <Sheet title={editing ? "Edit outfit" : "Build an outfit"} onClose={onClose} wide>
      <div className="af-inputwrap">
        <input className="af-input big" placeholder="Name this look" value={name}
          onChange={(e) => setName(e.target.value)} />
        <button className="af-mini" onClick={surprise} title="Surprise me"><Shuffle size={16} /></button>
      </div>

      {items.length === 0 ? (
        <p className="af-none">Your closet is empty — add pieces first.</p>
      ) : (
        <>
          <div className="af-selstrip">
            {selected.length === 0 && <span className="af-selhint">Tap pieces below to add them</span>}
            {selected.map((id) => {
              const it = items.find((x) => x.id === id); if (!it) return null;
              return (
                <span key={id} className="af-selthumb" onClick={() => toggle(id)}>
                  <img src={it.image} alt="" /><span className="af-selx"><X size={12} /></span>
                </span>
              );
            })}
          </div>

          {grouped.map((g) => (
            <div key={g.t.id} className="af-pickgroup">
              <span className="af-picklbl"><span className="af-emoji">{g.t.emoji}</span>{g.t.label}</span>
              <div className="af-pickrow">
                {g.list.map((it) => (
                  <button key={it.id} className={"af-picktile" + (selected.includes(it.id) ? " on" : "")}
                    onClick={() => toggle(it.id)}>
                    <img src={it.image} alt="" />
                    {selected.includes(it.id) && <span className="af-pickcheck"><Check size={14} /></span>}
                  </button>
                ))}
              </div>
            </div>
          ))}

          <Field label="Tags">
            <div className="af-chiprow">
              {TAG_PRESETS.map((t) => (
                <Chip key={t} on={tags.includes(t)} onClick={() => toggleTag(t)}>{t}</Chip>
              ))}
              {tags.filter((t) => !TAG_PRESETS.includes(t)).map((t) => (
                <Chip key={t} on onClick={() => toggleTag(t)}>{t} ✕</Chip>
              ))}
            </div>
            <div className="af-inputwrap" style={{ marginTop: 8 }}>
              <input className="af-input" placeholder="add your own tag" value={custom}
                onChange={(e) => setCustom(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && addCustom()} />
              <button className="af-mini" onClick={addCustom}><Plus size={16} /></button>
            </div>
          </Field>

          <button className="af-primary" onClick={save}><Check size={18} />{editing ? "Save changes" : "Save outfit"}</button>
        </>
      )}
    </Sheet>
  );
}

/* ================================================================== */
/*  OUTFIT DETAIL                                                     */
/* ================================================================== */
function OutfitDetail({ outfit, itemById, stat, logs, onClose, onWear, onEdit, onDelete }) {
  const imgs = outfit.itemIds.map(itemById).filter(Boolean);
  const s = stat || { count: 0, last: null, conf: [] };
  const recent = s.last && daysSince(s.last) <= 6;
  const avgConf = s.conf && s.conf.length ? Math.round(s.conf.reduce((a, b) => a + b, 0) / s.conf.length) : 0;

  return (
    <Sheet title={outfit.name || "Untitled look"} onClose={onClose} wide>
      {recent && (
        <div className="af-warn">
          <Clock size={15} />You wore this {daysSince(s.last)} {daysSince(s.last) === 1 ? "day" : "days"} ago — maybe switch it up?
        </div>
      )}

      <div className="af-detailcollage">
        {imgs.map((it) => (
          <span key={it.id} className="af-tile">
            <span className="af-glow soft" style={{ background: it.colorHex }} />
            <img src={it.image} alt={it.name} />
          </span>
        ))}
      </div>

      {outfit.tags?.length > 0 && (
        <div className="af-detailtags">
          {outfit.tags.map((t) => <span key={t} className="af-dt">{t}</span>)}
        </div>
      )}

      <div className="af-statrow">
        <div className="af-statcell"><span className="af-statn">{s.count}</span><span className="af-statl">times worn</span></div>
        <div className="af-statcell"><span className="af-statn">{s.last ? daysSince(s.last) + "d" : "—"}</span><span className="af-statl">since last</span></div>
        <div className="af-statcell">
          <span className="af-statn">{avgConf ? <Hearts value={avgConf} small readOnly inline /> : "—"}</span>
          <span className="af-statl">avg feel</span>
        </div>
      </div>

      <button className="af-primary" onClick={onWear}><Calendar size={18} />Wear today</button>

      {logs.length > 0 && (
        <div className="af-minihist">
          <span className="af-picklbl">Recent wears</span>
          {logs.slice(0, 4).map((l) => (
            <div key={l.id} className="af-minirow">
              <span>{fmtDate(l.date)}</span>
              <span className="af-minitag">{[l.occasion, l.location].filter(Boolean).join(" · ") || "—"}</span>
              <Hearts value={l.confidence} small readOnly />
            </div>
          ))}
        </div>
      )}

      <div className="af-detailactions">
        <button className="af-ghost" onClick={onEdit}>Edit</button>
        <button className="af-danger ghost" onClick={onDelete}><Trash2 size={16} />Delete</button>
      </div>
    </Sheet>
  );
}

/* ================================================================== */
/*  WEAR LOG                                                          */
/* ================================================================== */
function WearLog({ outfit, onClose, onSave }) {
  const [date, setDate] = useState(today());
  const [occasion, setOccasion] = useState("");
  const [location, setLocation] = useState("");
  const [confidence, setConfidence] = useState(4);

  return (
    <Sheet title="Log this wear" onClose={onClose}>
      <p className="af-wearsub">{outfit.name || "Untitled look"}</p>

      <Field label="Date">
        <input type="date" className="af-input" value={date} max={today()} onChange={(e) => setDate(e.target.value)} />
      </Field>

      <Field label="Occasion">
        <div className="af-chiprow">
          {["casual", "work", "party", "date night", "dinner", "school"].map((o) => (
            <Chip key={o} on={occasion === o} onClick={() => setOccasion(occasion === o ? "" : o)}>{o}</Chip>
          ))}
        </div>
      </Field>

      <Field label="Where / who with">
        <input className="af-input" placeholder="e.g. office, Mia's birthday" value={location}
          onChange={(e) => setLocation(e.target.value)} />
      </Field>

      <Field label="How did it feel?">
        <Hearts value={confidence} onChange={setConfidence} />
      </Field>

      <button className="af-primary" onClick={() => onSave({ outfitId: outfit.id, date, occasion, location, confidence })}>
        <Check size={18} />Save wear
      </button>
    </Sheet>
  );
}

/* ================================================================== */
/*  SHARED UI                                                         */
/* ================================================================== */
function Sheet({ title, children, onClose, wide }) {
  useEffect(() => {
    const h = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [onClose]);
  return (
    <div className="af-overlay" onClick={onClose}>
      <div className={"af-sheet" + (wide ? " wide" : "")} onClick={(e) => e.stopPropagation()}>
        <div className="af-sheethead">
          <button className="af-icon-btn" onClick={onClose}><ChevronLeft size={18} /></button>
          <span className="af-sheettitle">{title}</span>
          <button className="af-icon-btn" onClick={onClose}><X size={18} /></button>
        </div>
        <div className="af-sheetbody">{children}</div>
      </div>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <label className="af-field">
      <span className="af-fieldlbl">{label}</span>
      {children}
    </label>
  );
}

function Chip({ on, onClick, children }) {
  return (
    <button type="button" className={"af-chip" + (on ? " on" : "")} onClick={onClick}>{children}</button>
  );
}

function Hearts({ value = 0, onChange, small, readOnly, inline }) {
  const size = small ? 14 : 26;
  return (
    <div className={"af-hearts" + (inline ? " inline" : "")}>
      {[1, 2, 3, 4, 5].map((n) => (
        <button key={n} type="button" disabled={readOnly}
          className={"af-heart" + (n <= value ? " on" : "") + (readOnly ? " ro" : "")}
          onClick={() => onChange && onChange(n)}>
          <Heart size={size} fill={n <= value ? "currentColor" : "none"} />
        </button>
      ))}
    </div>
  );
}

function Empty({ icon, title, body, cta, onCta }) {
  return (
    <div className="af-empty af-in">
      <div className="af-emptyic">{icon}</div>
      <h2 className="af-emptyt">{title}</h2>
      <p className="af-emptyb">{body}</p>
      {cta && <button className="af-primary compact" onClick={onCta}><Plus size={17} />{cta}</button>}
    </div>
  );
}

/* ================================================================== */
/*  STYLES                                                            */
/* ================================================================== */
function Style() {
  return (
    <style>{`
@import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap');

.af, .af * { box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
.af {
  --a1:#b794f6; --a2:#f6a5c0; --a3:#f9c784;
  --aura:linear-gradient(135deg,#b794f6,#f6a5c0 55%,#f9c784);
  --danger:#f47a86; --good:#5ad1a6;
  font-family:'Plus Jakarta Sans',system-ui,sans-serif;
  color:var(--text); background:var(--bg);
  min-height:100vh; width:100%; position:relative;
  padding-bottom:150px; overflow-x:hidden;
}
.af[data-theme="dark"]{
  --bg:#14101c; --bg2:#0f0b16; --surface:#1e1826; --elevated:#271f31;
  --text:#f3eefa; --muted:#a79bb8; --border:rgba(255,255,255,.08);
  --border2:rgba(255,255,255,.15); --shadow:0 16px 50px rgba(0,0,0,.55);
  --field:#171220;
}
.af[data-theme="light"]{
  --bg:#f6f2fb; --bg2:#efe9f5; --surface:#ffffff; --elevated:#ffffff;
  --text:#211a2e; --muted:#736a86; --border:rgba(40,25,60,.09);
  --border2:rgba(40,25,60,.16); --shadow:0 16px 44px rgba(90,60,130,.14);
  --field:#f4f0f9;
}
.af::before{
  content:""; position:fixed; inset:0; pointer-events:none; z-index:0;
  background:
    radial-gradient(60vw 40vh at 85% -5%, rgba(183,148,246,.16), transparent 60%),
    radial-gradient(50vw 40vh at 0% 8%, rgba(246,165,192,.12), transparent 55%);
}
.af > * { position:relative; z-index:1; }
@media(prefers-reduced-motion: reduce){ .af *{ animation:none !important; transition:none !important; } }

/* header */
.af-header{
  position:sticky; top:0; z-index:20; display:flex; align-items:center; justify-content:space-between;
  padding:16px 18px 12px; backdrop-filter:blur(14px);
  background:color-mix(in srgb, var(--bg) 72%, transparent);
  border-bottom:1px solid var(--border);
}
.af-brand{ display:flex; align-items:center; gap:10px; }
.af-mark{ width:24px; height:24px; border-radius:8px; background:var(--aura);
  box-shadow:0 0 18px rgba(183,148,246,.5); }
.af-word{ font-family:'Fraunces',serif; font-weight:600; font-size:23px; letter-spacing:-.01em; }
.af-icon-btn{
  width:38px; height:38px; display:grid; place-items:center; border-radius:12px;
  background:var(--surface); border:1px solid var(--border); color:var(--text); cursor:pointer;
  transition:transform .15s, background .2s;
}
.af-icon-btn:active{ transform:scale(.92); }

/* views */
.af-main{ padding:8px 16px 0; max-width:760px; margin:0 auto; }
.af-view{ animation:fade .35s ease; }
.af-viewhead{ display:flex; align-items:flex-end; justify-content:space-between; padding:14px 2px 14px; }
.af-h1{ font-family:'Fraunces',serif; font-weight:600; font-size:30px; margin:0; letter-spacing:-.02em; }
.af-sub{ color:var(--muted); font-size:13.5px; margin:2px 0 0; }

.af-filters{ display:flex; gap:8px; overflow-x:auto; padding:2px 2px 14px; scrollbar-width:none; }
.af-filters::-webkit-scrollbar{ display:none; }

/* chips */
.af-chip{
  display:inline-flex; align-items:center; gap:6px; white-space:nowrap;
  padding:8px 14px; border-radius:999px; font-size:13px; font-weight:600; cursor:pointer;
  background:var(--surface); color:var(--muted); border:1px solid var(--border);
  transition:all .18s;
}
.af-chip.on{ color:#1b1226; background:var(--aura); border-color:transparent; box-shadow:0 6px 18px rgba(183,148,246,.35); }
.af-chip:active{ transform:scale(.95); }
.af-emoji{ font-size:14px; line-height:1; }
.af-chiprow{ display:flex; flex-wrap:wrap; gap:8px; }

/* masonry closet */
.af-masonry{ column-count:2; column-gap:12px; padding-bottom:20px; }
@media(min-width:560px){ .af-masonry{ column-count:3; } }
@media(min-width:760px){ .af-masonry{ column-count:4; } }
.af-card{
  display:block; width:100%; margin:0 0 12px; break-inside:avoid; position:relative;
  border-radius:20px; overflow:hidden; cursor:pointer; border:1px solid var(--border);
  background:var(--surface); padding:0; text-align:left;
  transition:transform .2s, box-shadow .2s;
}
.af-card:hover{ transform:translateY(-3px); box-shadow:var(--shadow); }
.af-card:active{ transform:scale(.98); }
.af-card img{ width:100%; display:block; }
.af-glow{ position:absolute; inset:-30% -10% 30%; filter:blur(38px); opacity:.42; z-index:0; }
.af-glow.soft{ opacity:.3; }
.af-glow.big{ inset:-20%; filter:blur(55px); opacity:.4; }
.af-card img, .af-cardmeta{ position:relative; z-index:1; }
.af-cardmeta{ display:flex; align-items:center; justify-content:space-between; gap:6px; padding:9px 12px 11px; }
.af-cardname{ font-size:12.5px; font-weight:600; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.af-wornpill{ font-size:11px; font-weight:700; color:var(--muted); }

/* outfit grid */
.af-outfitgrid{ display:grid; grid-template-columns:1fr 1fr; gap:14px; padding-bottom:20px; }
@media(min-width:620px){ .af-outfitgrid{ grid-template-columns:1fr 1fr 1fr; } }
.af-outfit{
  text-align:left; cursor:pointer; padding:0; border-radius:22px; overflow:hidden;
  border:1px solid var(--border); background:var(--surface);
  transition:transform .2s, box-shadow .2s;
}
.af-outfit:hover{ transform:translateY(-3px); box-shadow:var(--shadow); }
.af-outfit:active{ transform:scale(.98); }
.af-collage{ display:grid; gap:2px; aspect-ratio:1; background:var(--border); }
.af-collage.n1{ grid-template-columns:1fr; }
.af-collage.n2{ grid-template-columns:1fr 1fr; }
.af-collage.n3{ grid-template-columns:1fr 1fr; }
.af-collage.n3 .af-tile:first-child{ grid-row:span 2; }
.af-collage.n4{ grid-template-columns:1fr 1fr; }
.af-tile{ position:relative; overflow:hidden; background:var(--bg2); }
.af-tile img{ width:100%; height:100%; object-fit:cover; position:relative; z-index:1; }
.af-outfitfoot{ padding:11px 13px 13px; }
.af-outfitname{ font-weight:600; font-size:14px; display:block; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.af-outfitmeta{ margin-top:4px; }
.af-recent{ font-size:11.5px; font-weight:700; color:var(--a3); }
.af-muted-sm{ font-size:11.5px; color:var(--muted); }

/* history */
.af-stats{ display:flex; flex-direction:column; gap:10px; margin-bottom:18px; }
.af-stat{ display:flex; align-items:center; gap:12px; padding:14px 16px; border-radius:18px;
  background:var(--surface); border:1px solid var(--border); }
.af-stat-ic{ width:34px; height:34px; border-radius:11px; display:grid; place-items:center;
  background:var(--aura); color:#1b1226; }
.af-stat-lbl{ display:block; font-size:11.5px; color:var(--muted); font-weight:600; }
.af-stat-val{ display:block; font-size:14.5px; font-weight:700; margin-top:1px; }
.af-timeline{ display:flex; flex-direction:column; gap:12px; padding-bottom:20px; }
.af-tlrow{ display:flex; gap:12px; }
.af-tldate{ flex-shrink:0; width:42px; text-align:center; padding-top:14px; }
.af-tld{ display:block; font-family:'Fraunces',serif; font-size:20px; font-weight:600; line-height:1; }
.af-tlm{ display:block; font-size:11px; color:var(--muted); text-transform:uppercase; letter-spacing:.05em; }
.af-tlcard{ flex:1; display:flex; align-items:center; gap:12px; padding:12px 14px; border-radius:18px;
  background:var(--surface); border:1px solid var(--border); }
.af-tlimgs{ display:flex; }
.af-tlimgs img{ width:38px; height:46px; object-fit:cover; border-radius:9px; margin-left:-10px;
  border:2px solid var(--surface); }
.af-tlimgs img:first-child{ margin-left:0; }
.af-tlinfo{ flex:1; min-width:0; }
.af-tlname{ font-weight:600; font-size:13.5px; display:block; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.af-tltags{ display:flex; flex-wrap:wrap; gap:6px; margin-top:3px; }
.af-inlinetag{ display:inline-flex; align-items:center; gap:3px; font-size:11px; color:var(--muted); }

/* empty */
.af-empty{ text-align:center; padding:56px 24px; max-width:340px; margin:0 auto; }
.af-emptyic{ font-size:52px; margin-bottom:14px; }
.af-emptyt{ font-family:'Fraunces',serif; font-size:22px; font-weight:600; margin:0 0 8px; }
.af-emptyb{ color:var(--muted); font-size:14px; line-height:1.55; margin:0 0 22px; }
.af-none{ color:var(--muted); text-align:center; padding:40px 0; font-size:14px; }

/* buttons */
.af-primary{
  width:100%; display:flex; align-items:center; justify-content:center; gap:9px; margin-top:18px;
  padding:15px; border-radius:16px; border:none; cursor:pointer;
  font-family:inherit; font-weight:700; font-size:15px; color:#1b1226; background:var(--aura);
  box-shadow:0 10px 26px rgba(183,148,246,.4); transition:transform .15s;
}
.af-primary.compact{ width:auto; padding:13px 22px; margin-top:0; }
.af-primary:active{ transform:scale(.97); }
.af-ghost{ display:inline-flex; align-items:center; gap:7px; padding:9px 15px; border-radius:12px;
  background:var(--surface); border:1px solid var(--border2); color:var(--text);
  font-family:inherit; font-weight:600; font-size:13.5px; cursor:pointer; transition:transform .15s; }
.af-ghost:active{ transform:scale(.95); }
.af-danger{ width:100%; display:flex; align-items:center; justify-content:center; gap:8px; margin-top:16px;
  padding:13px; border-radius:14px; cursor:pointer; font-family:inherit; font-weight:600; font-size:14px;
  color:var(--danger); background:transparent; border:1px solid var(--border2); transition:transform .15s; }
.af-danger.ghost{ margin-top:0; width:auto; padding:9px 15px; }
.af-danger:active{ transform:scale(.96); }

/* FAB */
.af-fab{
  position:fixed; left:50%; transform:translateX(-50%); bottom:88px; z-index:30;
  display:flex; align-items:center; gap:8px; padding:13px 22px 13px 18px; border-radius:999px; border:none;
  font-family:inherit; font-weight:700; font-size:14.5px; color:#1b1226; background:var(--aura);
  box-shadow:0 12px 34px rgba(183,148,246,.5); cursor:pointer; animation:fabin .4s ease; transition:transform .15s;
}
@keyframes fabin{ from{ transform:translateX(-50%) translateY(12px); opacity:0; } to{ transform:translateX(-50%) translateY(0); opacity:1; } }
.af-fab:active{ transform:translateX(-50%) scale(.95); }

/* bottom nav */
.af-nav{
  position:fixed; left:0; right:0; bottom:0; z-index:25; display:flex; justify-content:space-around;
  padding:8px 12px calc(8px + env(safe-area-inset-bottom)); backdrop-filter:blur(16px);
  background:color-mix(in srgb, var(--bg) 82%, transparent); border-top:1px solid var(--border);
}
.af-navbtn{ display:flex; flex-direction:column; align-items:center; gap:3px; padding:6px 18px;
  background:none; border:none; color:var(--muted); font-family:inherit; font-size:11px; font-weight:600;
  cursor:pointer; transition:color .2s, transform .15s; }
.af-navbtn.on{ color:var(--text); }
.af-navbtn.on svg{ color:var(--a1); }
.af-navbtn:active{ transform:scale(.9); }

/* overlay + sheet */
.af-overlay{ position:fixed; inset:0; z-index:50; display:flex; align-items:flex-end; justify-content:center;
  background:rgba(10,6,16,.55); backdrop-filter:blur(6px); animation:fade .25s ease; }
@media(min-width:620px){ .af-overlay{ align-items:center; padding:20px; } }
.af-sheet{ width:100%; max-width:480px; max-height:92vh; overflow-y:auto; background:var(--bg);
  border:1px solid var(--border); border-radius:26px 26px 0 0; box-shadow:var(--shadow);
  animation:slideup .3s cubic-bezier(.2,.9,.3,1); }
.af-sheet.wide{ max-width:560px; }
@media(min-width:620px){ .af-sheet{ border-radius:26px; animation:pop .3s ease; } }
.af-sheethead{ position:sticky; top:0; z-index:2; display:flex; align-items:center; justify-content:space-between;
  gap:10px; padding:14px 14px 12px; background:color-mix(in srgb, var(--bg) 88%, transparent);
  backdrop-filter:blur(10px); border-bottom:1px solid var(--border); }
.af-sheettitle{ font-family:'Fraunces',serif; font-weight:600; font-size:17px; flex:1; text-align:center;
  overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.af-sheetbody{ padding:18px; }

/* fields + inputs */
.af-field{ display:block; margin-top:16px; }
.af-fieldlbl{ display:block; font-size:12px; font-weight:700; color:var(--muted); margin-bottom:8px;
  text-transform:uppercase; letter-spacing:.05em; }
.af-input{ width:100%; padding:13px 14px; border-radius:13px; border:1px solid var(--border2);
  background:var(--field); color:var(--text); font-family:inherit; font-size:15px; outline:none;
  transition:border-color .2s, box-shadow .2s; }
.af-input:focus{ border-color:var(--a1); box-shadow:0 0 0 3px rgba(183,148,246,.18); }
.af-input.big{ font-size:17px; font-weight:600; }
.af-two{ display:grid; grid-template-columns:1fr 1fr; gap:12px; }
.af-two .af-field{ margin-top:16px; }
.af-inputwrap{ display:flex; align-items:center; gap:8px; }
.af-inputwrap .af-input{ flex:1; }
.af-swatch{ width:22px; height:22px; border-radius:7px; flex-shrink:0; border:1px solid var(--border2); }
.af-swatch.sm{ width:14px; height:14px; border-radius:5px; }
.af-mini{ width:44px; height:46px; flex-shrink:0; display:grid; place-items:center; border-radius:13px;
  background:var(--surface); border:1px solid var(--border2); color:var(--text); cursor:pointer; transition:transform .15s; }
.af-mini:active{ transform:scale(.9); }

/* upload */
.af-drop{ width:100%; display:flex; flex-direction:column; align-items:center; gap:8px; padding:44px 20px;
  border-radius:20px; border:1.5px dashed var(--border2); background:var(--surface); color:var(--muted);
  cursor:pointer; font-family:inherit; transition:border-color .2s, transform .15s; }
.af-drop:active{ transform:scale(.98); }
.af-drop-t{ font-weight:700; font-size:15px; color:var(--text); }
.af-drop-s{ font-size:12.5px; text-align:center; max-width:220px; }
.af-preview{ position:relative; border-radius:20px; overflow:hidden; border:1px solid var(--border);
  background:var(--surface); display:flex; justify-content:center; }
.af-preview img{ max-height:320px; width:auto; max-width:100%; display:block; position:relative; z-index:1; }
.af-repick{ position:absolute; top:10px; right:10px; z-index:2; padding:7px 13px; border-radius:999px;
  background:rgba(20,12,28,.6); backdrop-filter:blur(8px); color:#fff; border:1px solid rgba(255,255,255,.2);
  font-family:inherit; font-size:12px; font-weight:600; cursor:pointer; }
.af-ai{ width:100%; display:flex; align-items:center; justify-content:center; gap:9px; margin-top:14px;
  padding:13px; border-radius:14px; cursor:pointer; font-family:inherit; font-weight:700; font-size:14px;
  color:var(--text); background:var(--surface); border:1px solid var(--a1);
  box-shadow:0 0 0 3px rgba(183,148,246,.1); transition:transform .15s; }
.af-ai:active{ transform:scale(.97); }
.af-ai:disabled{ opacity:.7; }

/* detail bits */
.af-detailtags{ display:flex; flex-wrap:wrap; gap:8px; margin-top:16px; }
.af-dt{ display:inline-flex; align-items:center; gap:6px; padding:7px 13px; border-radius:999px;
  background:var(--surface); border:1px solid var(--border); font-size:13px; font-weight:600; text-transform:capitalize; }
.af-wornline{ display:flex; align-items:center; gap:8px; margin-top:16px; color:var(--muted); font-size:13.5px; font-weight:600; }
.af-wornline svg{ color:var(--a2); }

/* build */
.af-selstrip{ display:flex; gap:8px; overflow-x:auto; padding:14px 0 6px; min-height:64px; scrollbar-width:none; }
.af-selstrip::-webkit-scrollbar{ display:none; }
.af-selhint{ color:var(--muted); font-size:13px; align-self:center; }
.af-selthumb{ position:relative; flex-shrink:0; width:54px; height:66px; border-radius:12px; overflow:hidden;
  border:1px solid var(--border2); cursor:pointer; }
.af-selthumb img{ width:100%; height:100%; object-fit:cover; }
.af-selx{ position:absolute; top:2px; right:2px; width:18px; height:18px; border-radius:50%;
  background:rgba(20,12,28,.75); color:#fff; display:grid; place-items:center; }
.af-pickgroup{ margin-top:18px; }
.af-picklbl{ display:flex; align-items:center; gap:6px; font-size:12px; font-weight:700; color:var(--muted);
  text-transform:uppercase; letter-spacing:.05em; margin-bottom:10px; }
.af-pickrow{ display:flex; gap:10px; overflow-x:auto; padding-bottom:6px; scrollbar-width:none; }
.af-pickrow::-webkit-scrollbar{ display:none; }
.af-picktile{ position:relative; flex-shrink:0; width:74px; height:90px; border-radius:14px; overflow:hidden;
  border:2px solid var(--border); background:var(--surface); cursor:pointer; padding:0; transition:transform .15s; }
.af-picktile.on{ border-color:var(--a1); box-shadow:0 0 0 3px rgba(183,148,246,.25); }
.af-picktile:active{ transform:scale(.94); }
.af-picktile img{ width:100%; height:100%; object-fit:cover; }
.af-pickcheck{ position:absolute; top:5px; right:5px; width:22px; height:22px; border-radius:50%;
  background:var(--aura); color:#1b1226; display:grid; place-items:center; }

/* outfit detail collage */
.af-detailcollage{ display:flex; flex-wrap:wrap; gap:10px; margin-top:4px; }
.af-detailcollage .af-tile{ width:calc(33.33% - 7px); aspect-ratio:.82; border-radius:16px; border:1px solid var(--border); }
.af-detailcollage .af-tile img{ border-radius:16px; }
.af-statrow{ display:flex; gap:10px; margin-top:18px; }
.af-statcell{ flex:1; text-align:center; padding:14px 8px; border-radius:16px; background:var(--surface);
  border:1px solid var(--border); }
.af-statn{ display:block; font-family:'Fraunces',serif; font-size:22px; font-weight:600; }
.af-statl{ display:block; font-size:11px; color:var(--muted); margin-top:2px; }
.af-warn{ display:flex; align-items:center; gap:9px; padding:12px 14px; border-radius:14px; margin-bottom:6px;
  background:color-mix(in srgb, var(--a3) 16%, var(--surface)); border:1px solid color-mix(in srgb, var(--a3) 40%, transparent);
  font-size:13px; font-weight:600; }
.af-warn svg{ color:var(--a3); flex-shrink:0; }
.af-minihist{ margin-top:20px; }
.af-minirow{ display:flex; align-items:center; gap:10px; padding:10px 0; border-bottom:1px solid var(--border);
  font-size:12.5px; }
.af-minirow > span:first-child{ font-weight:600; }
.af-minitag{ flex:1; color:var(--muted); overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.af-detailactions{ display:flex; gap:10px; margin-top:18px; }
.af-detailactions .af-ghost{ flex:1; justify-content:center; }
.af-wearsub{ color:var(--muted); font-size:14px; margin:0 0 4px; font-weight:600; }

/* hearts */
.af-hearts{ display:flex; gap:6px; }
.af-hearts.inline{ gap:2px; justify-content:center; }
.af-heart{ background:none; border:none; padding:0; cursor:pointer; color:var(--border2); transition:transform .12s, color .18s; }
.af-heart.on{ color:var(--a2); }
.af-heart.ro{ cursor:default; }
.af-heart:not(.ro):active{ transform:scale(.8); }

/* splash */
.af-splash{ min-height:100vh; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:18px; }
.af-logo-mark{ width:56px; height:56px; border-radius:18px; background:var(--aura);
  box-shadow:0 0 40px rgba(183,148,246,.6); animation:breathe 1.6s ease-in-out infinite; }
.af-splash-txt{ color:var(--muted); font-size:14px; font-weight:600; }

/* toast */
.af-toast{ position:fixed; left:50%; transform:translateX(-50%); bottom:160px; z-index:60;
  padding:12px 20px; border-radius:999px; background:var(--elevated); color:var(--text);
  border:1px solid var(--border2); box-shadow:var(--shadow); font-size:13.5px; font-weight:600;
  animation:toast .3s ease; }

.af-spin{ animation:spin 1s linear infinite; }
@keyframes spin{ to{ transform:rotate(360deg); } }
@keyframes fade{ from{ opacity:0; } to{ opacity:1; } }
@keyframes slideup{ from{ transform:translateY(40px); opacity:.6; } to{ transform:translateY(0); opacity:1; } }
@keyframes pop{ from{ transform:scale(.94); opacity:0; } to{ transform:scale(1); opacity:1; } }
@keyframes toast{ from{ transform:translateX(-50%) translateY(10px); opacity:0; } to{ transform:translateX(-50%) translateY(0); opacity:1; } }
@keyframes breathe{ 0%,100%{ transform:scale(1); opacity:.85; } 50%{ transform:scale(1.08); opacity:1; } }
.af-in{ animation:fadeup .45s ease both; }
@keyframes fadeup{ from{ transform:translateY(14px); opacity:0; } to{ transform:translateY(0); opacity:1; } }
`}</style>
  );
}
